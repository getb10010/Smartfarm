// web3Function.ts
import { Web3Function } from "@gelatonetwork/web3-functions-sdk";
import axios from "axios";
Web3Function.onRun(async (context) => {
  const { userArgs, secrets, storage } = context;
  const lat = userArgs.lat ?? 43.2567;
  const lon = userArgs.lon ?? 76.9286;
  const frostThreshold = userArgs.frostThreshold ?? -5;
  const droughtPrecipMin = userArgs.droughtPrecipMin ?? 10;
  const agentWebhookUrl = await secrets.get("AGENT_WEBHOOK_URL");
  const metgisKey = await secrets.get("METGIS_API_KEY");
  let temperature = 20;
  let precipitation7d = 50;
  let humidity = 50;
  let windSpeed = 3;
  let source = "unknown";
  if (metgisKey) {
    try {
      const res = await axios.get("https://api.metgis.com/forecast/point", {
        params: { lat, lon, key: metgisKey, format: "json" },
        timeout: 8e3
      });
      const current = res.data?.current;
      if (current) {
        temperature = current.temperature ?? 20;
        humidity = current.humidity ?? 50;
        windSpeed = current.wind_speed ?? 3;
        source = "MetGIS";
      }
    } catch {
      console.log("[Gelato] MetGIS failed, falling back to Open-Meteo");
    }
  }
  if (source === "unknown") {
    try {
      const res = await axios.get("https://api.open-meteo.com/v1/forecast", {
        params: {
          latitude: lat,
          longitude: lon,
          current: "temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation",
          daily: "precipitation_sum",
          past_days: 7,
          timezone: "auto"
        },
        timeout: 8e3
      });
      const current = res.data?.current;
      temperature = current?.temperature_2m ?? 20;
      humidity = current?.relative_humidity_2m ?? 50;
      windSpeed = current?.wind_speed_10m ?? 3;
      source = "Open-Meteo";
      const dailyPrecip = res.data?.daily?.precipitation_sum ?? [];
      precipitation7d = dailyPrecip.reduce((a, b) => a + (b ?? 0), 0);
    } catch (e) {
      return { canExec: false, message: `All weather APIs failed: ${e.message}` };
    }
  }
  console.log(`[Gelato SmartFarmer] ${source}: T=${temperature}\xB0C, Precip7d=${precipitation7d.toFixed(1)}\u043C\u043C, H=${humidity}%, W=${windSpeed}\u043C/\u0441 at [${lat},${lon}]`);
  const frostTriggered = temperature < frostThreshold;
  const droughtTriggered = precipitation7d < droughtPrecipMin;
  if (!frostTriggered && !droughtTriggered) {
    await storage.set("lastNormalCheck", Date.now().toString());
    return {
      canExec: false,
      message: `Normal: T=${temperature}\xB0C (threshold: ${frostThreshold}\xB0C), Precip7d=${precipitation7d.toFixed(1)}\u043C\u043C (min: ${droughtPrecipMin}\u043C\u043C)`
    };
  }
  const triggerType = frostTriggered ? "FROST" : "DROUGHT";
  const payload = {
    event: "GELATO_WEATHER_TRIGGER",
    triggerType,
    data: {
      temperature,
      precipitation7d,
      humidity,
      windSpeed,
      source,
      lat,
      lon,
      frostThreshold,
      droughtPrecipMin
    },
    timestamp: Date.now()
  };
  console.log(`[Gelato SmartFarmer] \u{1F6A8} ${triggerType} TRIGGER! Notifying agent...`);
  if (agentWebhookUrl) {
    try {
      await axios.post(agentWebhookUrl, payload, { timeout: 15e3 });
      console.log(`[Gelato SmartFarmer] \u2705 Agent notified successfully`);
    } catch (e) {
      console.log(`[Gelato SmartFarmer] \u26A0\uFE0F Agent webhook failed: ${e.message}`);
    }
  } else {
    console.log(`[Gelato SmartFarmer] \u2139\uFE0F No AGENT_WEBHOOK_URL configured. Trigger logged only.`);
  }
  await storage.set("lastTrigger", JSON.stringify({
    type: triggerType,
    temperature,
    precipitation7d,
    timestamp: Date.now()
  }));
  return {
    canExec: false,
    message: `\u{1F6A8} ${triggerType} triggered! T=${temperature}\xB0C, Precip7d=${precipitation7d.toFixed(1)}\u043C\u043C. Agent notified via webhook.`
  };
});
